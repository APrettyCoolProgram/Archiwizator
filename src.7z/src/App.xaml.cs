﻿/* PROJECT: Archiwizator (https://github.com/aprettycoolprogram/Archiwizator)
 *    FILE: Archiwizator.App.xaml.cs
 * UPDATED: 12-29-2020-9:37 AM
 * LICENSE: Apache v2 (https://apache.org/licenses/LICENSE-2.0)
 *          Copyright 2020 A Pretty Cool Program All rights reserved
 */

using System.Windows;

namespace Archiwizator
{
    public partial class App : Application
    {
    }
}
