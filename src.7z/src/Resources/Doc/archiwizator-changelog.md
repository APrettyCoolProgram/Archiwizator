﻿> PROJECT: Archiwizator<br>
> FILE: archiwizator-changelog.md

# Archiwizator: Changelog

#### v1.0
`INFO` Initial release